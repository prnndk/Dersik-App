@extends('dashboard.layouts.main')
@section('container')
    {{ $data->nama }}
@endsection